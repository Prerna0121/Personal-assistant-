import speech_recognition as sr
import pyttsx3
import requests
import time
import pyjokes
from datetime import datetime

# Initialize the speech engine
engine = pyttsx3.init()

def speak(text):
    """Function to convert text to speech."""
    engine.say(text)
    engine.runAndWait()

def listen():
    """Function to capture audio input."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    try:
        print("Recognizing...")
        query = recognizer.recognize_google(audio)
        print(f"You said: {query}")
        return query.lower()
    except sr.UnknownValueError:
        speak("Sorry, I could not understand the audio.")
        return None
    except sr.RequestError:
        speak("Sorry, there was an issue with the speech service.")
        return None

def get_weather():
    """Function to get weather from OpenWeather API."""
    api_key = "YOUR_OPENWEATHER_API_KEY"  # Replace with your actual API key
    city = "New Delhi"  # Replace with your city name

    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    response = requests.get(url)

    if response.status_code == 200:  # Check if request was successful
        data = response.json()
        temp = data["main"]["temp"]
        description = data["weather"][0]["description"]
        speak(f"The temperature in {city} is {temp} degrees Celsius with {description}.")
    else:
        speak("Sorry, I couldn't fetch the weather information. Please check your API key or internet connection.")


def get_news():
    """Function to get the latest news using News API."""
    api_key = "YOUR_NEWS_API_KEY"
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={api_key}"
    response = requests.get(url)
    data = response.json()

    if "articles" in data:
        articles = data["articles"]
        speak("Here are the top news headlines:")
        for article in articles[:5]:
            title = article.get("title", "No title available")
            description = article.get("description", "No description available")
            speak(f"Title: {title}. Description: {description}")
    else:
        speak("Sorry, I could not fetch the news.")

def tell_joke():
    """Function to tell a random joke using pyjokes."""
    joke = pyjokes.get_joke()
    speak(joke)

def set_reminder():
    """Function to set a reminder."""
    speak("What is the reminder?")
    reminder = listen()
    if reminder:
        speak(f"Reminder set: {reminder}")
        time.sleep(5)  # Wait for 5 seconds
        speak(f"Reminder: {reminder}")

def get_time():
    """Function to tell the current time."""
    current_time = datetime.now().strftime("%H:%M")
    speak(f"The current time is {current_time}.")

def main():
    """Main function to handle voice commands."""
    speak("Hello, I am your voice assistant. How can I help you today?")
    
    while True:
        query = listen()
        
        if query:
            if "weather" in query:
                get_weather()
            elif "news" in query:
                get_news()
            elif "joke" in query:
                tell_joke()
            elif "reminder" in query:
                set_reminder()
            elif "time" in query:
                get_time()
            elif "exit" in query or "quit" in query:
                speak("Goodbye!")
                break
            else:
                speak("Sorry, I didn't understand that. You can ask me about the weather, news, jokes, reminders, or time.")

if __name__ == "__main__":
    main()
